var natural = require ('natural');

natural.BayesClassifier.load('nvclassifier.json',natural.PorterStemmerRu,function(err,classifier){
    console.log(classifier.classify("Я тестировала с комментариев двача и оно работало почти отлично"));
})