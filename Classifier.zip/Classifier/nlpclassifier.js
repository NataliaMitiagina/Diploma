var natural = require ('natural');
var classifier = new natural.BayesClassifier(natural.PorterStemmerRu);

//External dataset

const data = require('./labeled.json');

data.forEach(item=>{
    classifier.addDocument(item.comment, item.toxic);
}) 
//Train

classifier.train();

//Apply
console.log(classifier.classify("Ты такой козел"));

//Save 

classifier.save('nvclassifier.json',function(err,classifier){});